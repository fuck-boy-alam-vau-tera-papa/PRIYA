a = 10
b = [10, 20, 30]

if a in b:
    pass

if a not in b:
    pass
